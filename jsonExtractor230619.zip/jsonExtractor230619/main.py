import os
import pandas as pd
import datetime
import json
import numpy as np

# Function to check if a value can be converted to float
def is_float(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

#1. Load complete CSV data
UK_data = pd.read_csv(os.getcwd()+"\\Input_parameters.csv")

#2. Extract individual .json files
current_date = datetime.datetime.now().strftime('%Y%m%d')
output_dir = os.getcwd() + '\\outputs'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

for region in UK_data.columns[2:]:
    region_data = UK_data.loc[:,["Parameter",region]]

    # Convert the types of the region_data DataFrame
    for col in region_data.columns:
        region_data[col] = region_data[col].apply(lambda x: float(x) if isinstance(x, (int, float)) else x if isinstance(x, str) else np.nan)

    region_data_dict = region_data.set_index('Parameter').T.to_dict('list')

    # get the first (and only) element of each list in the dictionary and convert to float if possible
    region_data_dict = {key: float(value[0]) if is_float(value[0]) else value[0] for key, value in region_data_dict.items()}

    # construct the file name
    file_name = f"{region}_{current_date}.json"
    file_path = os.path.join(output_dir, file_name)

    # write dictionary to json file
    with open(file_path, 'w') as f:
        json.dump(region_data_dict, f)

print("exported all regions to json formats")

